package com.example.notekelompok10;

/**
 * Created by IMMANUEL on 10/22/2017.
 */
public class List {

    // Labels table name
    public static final String TABLE = "List";

    // Labels Table Columns names
    public static final String KEY_ID = "id";
    public static final String KEY_value = "value";
    public static final String KEY_status = "status";
    public static final String KEY_updated_at = "updated_at";

    // property help us to keep data
    public int list_ID;
    public String value;
    public String status;
    //public String updated_at;

}
